Project ARIA — IEEE Journal Paper & Draft Package
=================================================
This package includes BOTH the full 19-page Journal Paper and the structured Draft Paper:

1. aria_draft_paper.tex:
   Contains the required academic draft sections:
   - a. Title and Author Details
   - b. Abstract
   - c. Keywords
   - d. Introduction
   - e. Objective(s)
   - f. Literature Review – Based on relevant and recent research papers
   - g. Research Gap Identified
   - h. References

2. aria_journal_paper.tex:
   The complete 19-page IEEE Transactions on Robotics publication manuscript
   with all mathematical derivations, 9 high-res figures, and experimental benchmarks.

Overleaf Upload Instructions:
-----------------------------
1. Log into your Overleaf account (https://www.overleaf.com).
2. Click "New Project" -> "Upload Project".
3. Select this .zip file (aria_journal_paper_overleaf.zip).
4. Under Settings, choose either `aria_draft_paper.tex` or `aria_journal_paper.tex` as Main Document.
5. Click "Recompile".
=================================================
