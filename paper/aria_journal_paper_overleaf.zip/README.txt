Project ARIA — IEEE Transactions Journal Paper Package
======================================================
Title: Project ARIA: A Cognitive Multi-Agent Vision-Language-Action Architecture
       for Autonomous Manipulation on Low-Cost 5-DoF Robotic Arms

Overleaf Upload Instructions:
-----------------------------
1. Log into your Overleaf account (https://www.overleaf.com).
2. Click "New Project" -> "Upload Project".
3. Select this .zip file (`aria_journal_paper_overleaf.zip`).
4. Overleaf will extract all files and open the project.
5. Make sure the Main Document in Overleaf Settings is set to `aria_journal_paper.tex`.
6. Click "Recompile" (default compiler: pdfLaTeX or XeLaTeX).

Package Contents:
-----------------
- aria_journal_paper.tex   : Main IEEE journal manuscript (19 pages)
- references.bib           : BibTeX database with all cited literature
- IEEEtran.cls             : IEEEtran class definition (v1.8b)
- IEEEtran.bst             : IEEEtran bibliography style
- figures/                 : High-resolution PNG figures (Fig 1 through Fig 9)
- fig*.png                 : Root copies of figures for robust path resolution
- aria_journal_paper.pdf   : Precompiled publication-ready reference PDF
======================================================
