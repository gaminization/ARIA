Project ARIA — Review-2 Research Paper Package (Overleaf)
=========================================================
Title: Project ARIA: A Cognitive Multi-Agent Vision-Language-Action Architecture
       for Autonomous Manipulation on Low-Cost 5-DoF Robotic Arms

Review-2 Required Sections Included:
------------------------------------
* Title and Author Details (Garv Arora, VIT)
* Abstract (150–250 words)
* Keywords (5–8)
* 1. Introduction & Objectives (4)
* 2. Literature Review (10–15 recent papers, 2023–2026) & Research Gap Identified
* 3. Proposed Methodology / Proposed System
     - Overall methodology
     - System architecture / block diagram
     - Detailed explanation of the proposed approach
     - Algorithms / techniques / models used
     - Workflow / process of the proposed system
* 4. Implementation / Experimental Setup
     - Hardware and software requirements
     - Dataset details
     - Tools, technologies, and frameworks used
     - Implementation procedure
     - Experimental setup
* 5. Results and Discussion
     - Experimental results / preliminary results
     - Tables, graphs, figures, or screenshots
     - Performance metrics
     - Comparison with existing methods
     - Discussion of the obtained results
* 6. Conclusion
     - Summary of the proposed work
     - Key findings / expected contribution
     - How the identified research gaps are addressed
     - Limitations, if any
     - Brief future scope
* References in IEEE format

Overleaf Upload Instructions:
-----------------------------
1. Log into your Overleaf account (https://www.overleaf.com).
2. Click "New Project" -> "Upload Project".
3. Select this .zip file (`aria_draft_paper_overleaf.zip`).
4. Overleaf will automatically detect `aria_draft_paper.tex` as Main Document.
5. Click "Recompile" (pdfLaTeX or XeLaTeX).
=========================================================
