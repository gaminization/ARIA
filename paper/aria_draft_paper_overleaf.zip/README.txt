Project ARIA — Draft Research Paper Package (Overleaf)
======================================================
Sections Included:
  a. Title and Author Details
  b. Abstract
  c. Keywords
  d. Introduction
  e. Objective(s)
  f. Literature Review – Based on relevant and recent research papers
  g. Research Gap Identified
  h. References

Overleaf Upload Instructions:
-----------------------------
1. Log into your Overleaf account (https://www.overleaf.com).
2. Click "New Project" -> "Upload Project".
3. Select this .zip file (aria_draft_paper_overleaf.zip).
4. Overleaf will automatically detect aria_draft_paper.tex.
5. Click "Recompile" to build your paper.
======================================================
